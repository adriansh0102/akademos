import React from "react";

const Input = () => {
  return (
    <div>
      <label
        htmlFor="name-input"
        className="block text-sm font-medium text-gray-600"
      >
        Nombre
      </label>
      <input
        type="text"
        id="name-input"
        placeholder="Ingresa tu nombre"
        className="mt-2 w-full px-4 py-2 text-gray-700 bg-gray-100 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#cd8702] focus:border-[#cd8702]"
      />
    </div>
  );
};

export default Input;
