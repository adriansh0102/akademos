import React from "react";

interface ButtonProps {
  type?: "button" | "submit" | "reset";
  variant?: "primary" | "secondary";
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({
  type = "button",
  variant = "primary",
  onClick,
  children,
  className = "",
}) => {
  // Estilos base para el botón
  const baseStyles =
    "px-6 py-2 rounded-md font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 cursor-pointer";

  // Estilos según la variante
  const variantStyles =
    variant === "primary"
      ? "bg-[#cd8702] text-white hover:bg-[#a56f00] focus:ring-[#cd8702]"
      : "bg-transparent text-gray-700 border border-gray-300 hover:bg-gray-100 hover:text-gray-700 focus:ring-gray-300";

  return (
    <button
      type={type}
      onClick={onClick}
      className={`${baseStyles} ${variantStyles} ${className}`}
    >
      {children}
    </button>
  );
};

export default Button;